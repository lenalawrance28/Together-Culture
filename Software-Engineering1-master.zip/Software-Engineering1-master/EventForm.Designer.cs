﻿namespace Software_Engineering1
{
    partial class EventForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EventForm));
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.roundedPanel1 = new Software_Engineering1.RoundedPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Turn_Up_and_Write = new System.Windows.Forms.Button();
            this.Monthly_Restorative_Rest = new System.Windows.Forms.Button();
            this.Art_Gathering = new System.Windows.Forms.Button();
            this.Mindfull_Kickboxing = new System.Windows.Forms.Button();
            this.Partner_Assisted_Yoga = new System.Windows.Forms.Button();
            this.Focusing_Workshop = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.roundedPanel8 = new Software_Engineering1.RoundedPanel();
            this.roundedPanel7 = new Software_Engineering1.RoundedPanel();
            this.roundedPanel6 = new Software_Engineering1.RoundedPanel();
            this.roundedPanel3 = new Software_Engineering1.RoundedPanel();
            this.roundedPanel5 = new Software_Engineering1.RoundedPanel();
            this.roundedPanel4 = new Software_Engineering1.RoundedPanel();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.roundedPanel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.CausesValidation = false;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Modern No. 20", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(682, 7);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(130, 37);
            this.button3.TabIndex = 3;
            this.button3.Text = "Membership";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.CausesValidation = false;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Modern No. 20", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(464, 8);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(93, 37);
            this.button1.TabIndex = 2;
            this.button1.Text = "Events";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.CausesValidation = false;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Modern No. 20", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(898, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(119, 37);
            this.button4.TabIndex = 4;
            this.button4.Text = "shop";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.CausesValidation = false;
            this.button2.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Modern No. 20", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(236, 8);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(105, 34);
            this.button2.TabIndex = 3;
            this.button2.Text = "Home";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkOrange;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Location = new System.Drawing.Point(-4, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1346, 63);
            this.panel2.TabIndex = 11;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(1084, 13);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(56, 21);
            this.label19.TabIndex = 7;
            this.label19.Text = "Profile";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(1196, 13);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(71, 24);
            this.label18.TabIndex = 6;
            this.label18.Text = "label18";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-1, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(111, 56);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Crimson;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.roundedPanel1);
            this.panel1.Location = new System.Drawing.Point(-4, 56);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1346, 345);
            this.panel1.TabIndex = 12;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Orange;
            this.label3.Location = new System.Drawing.Point(503, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(394, 38);
            this.label3.TabIndex = 6;
            this.label3.Text = "BOOK AN EVENT NOW";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(496, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(412, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "All events are free or discounted to members, and open to the public.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(583, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(268, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Welcome to Together Culture";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // roundedPanel1
            // 
            this.roundedPanel1.BackColor = System.Drawing.SystemColors.Control;
            this.roundedPanel1.BorderRadius = 50;
            this.roundedPanel1.Controls.Add(this.textBox1);
            this.roundedPanel1.Controls.Add(this.label6);
            this.roundedPanel1.Controls.Add(this.label4);
            this.roundedPanel1.Location = new System.Drawing.Point(334, 138);
            this.roundedPanel1.Name = "roundedPanel1";
            this.roundedPanel1.Size = new System.Drawing.Size(742, 239);
            this.roundedPanel1.TabIndex = 3;
            this.roundedPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel1_Paint);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(276, 121);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(283, 22);
            this.textBox1.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(158, 118);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 24);
            this.label6.TabIndex = 4;
            this.label6.Text = "Find Events";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(311, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 29);
            this.label4.TabIndex = 0;
            this.label4.Text = "Find Event";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Crimson;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(927, 398);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(145, 40);
            this.button5.TabIndex = 5;
            this.button5.Text = "FIND NOW";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Crimson;
            this.label7.Location = new System.Drawing.Point(63, 457);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(347, 36);
            this.label7.TabIndex = 17;
            this.label7.Text = "Upcoming Events Diary";
            this.label7.Click += new System.EventHandler(this.label7_Click_1);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(42, 525);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(733, 60);
            this.label8.TabIndex = 18;
            this.label8.Text = "From the big picture to the tiniest details, we handle it all, leaving you free t" +
    "o enjoy every moment.\r\n\r\nSpots fill quickly—secure your date now and make magic " +
    "happen!";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(142, 836);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 16);
            this.label9.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(100, 836);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 16);
            this.label10.TabIndex = 21;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(546, 836);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(227, 25);
            this.label11.TabIndex = 22;
            this.label11.Text = "Monthly Restorative Rest";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(1096, 836);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(127, 25);
            this.label12.TabIndex = 23;
            this.label12.Text = "Art Gathering";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(65, 829);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(172, 25);
            this.label13.TabIndex = 24;
            this.label13.Text = "Turn Up and Write";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(37, 1213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(180, 25);
            this.label5.TabIndex = 28;
            this.label5.Text = "Mindfull Kickboxing";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(579, 1213);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(211, 25);
            this.label14.TabIndex = 29;
            this.label14.Text = "Partner  Assisted Yoga";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(1059, 1213);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(187, 25);
            this.label15.TabIndex = 30;
            this.label15.Text = "Focusing Workshop";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Orange;
            this.label16.Location = new System.Drawing.Point(45, 19);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(352, 32);
            this.label16.TabIndex = 31;
            this.label16.Text = "Sign up to our newsletter";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(32, 88);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(246, 30);
            this.textBox2.TabIndex = 32;
            this.textBox2.Text = "First Name";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(297, 88);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(197, 30);
            this.textBox3.TabIndex = 33;
            this.textBox3.Text = "Last Name ";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(520, 88);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(279, 34);
            this.textBox4.TabIndex = 34;
            this.textBox4.Text = "Email";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Orange;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(882, 79);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(136, 50);
            this.button6.TabIndex = 35;
            this.button6.Text = "SIGN UP";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Crimson;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.button6);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.textBox4);
            this.panel3.Controls.Add(this.textBox3);
            this.panel3.Location = new System.Drawing.Point(12, 1332);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1379, 150);
            this.panel3.TabIndex = 36;
            // 
            // Turn_Up_and_Write
            // 
            this.Turn_Up_and_Write.BackColor = System.Drawing.Color.Crimson;
            this.Turn_Up_and_Write.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Turn_Up_and_Write.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Turn_Up_and_Write.ForeColor = System.Drawing.Color.White;
            this.Turn_Up_and_Write.Location = new System.Drawing.Point(70, 873);
            this.Turn_Up_and_Write.Name = "Turn_Up_and_Write";
            this.Turn_Up_and_Write.Size = new System.Drawing.Size(159, 34);
            this.Turn_Up_and_Write.TabIndex = 37;
            this.Turn_Up_and_Write.Text = "BOOK NOW";
            this.Turn_Up_and_Write.UseVisualStyleBackColor = false;
            this.Turn_Up_and_Write.Click += new System.EventHandler(this.button7_Click);
            // 
            // Monthly_Restorative_Rest
            // 
            this.Monthly_Restorative_Rest.BackColor = System.Drawing.Color.Crimson;
            this.Monthly_Restorative_Rest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Monthly_Restorative_Rest.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Monthly_Restorative_Rest.ForeColor = System.Drawing.Color.White;
            this.Monthly_Restorative_Rest.Location = new System.Drawing.Point(593, 873);
            this.Monthly_Restorative_Rest.Name = "Monthly_Restorative_Rest";
            this.Monthly_Restorative_Rest.Size = new System.Drawing.Size(159, 34);
            this.Monthly_Restorative_Rest.TabIndex = 38;
            this.Monthly_Restorative_Rest.Text = "BOOK NOW";
            this.Monthly_Restorative_Rest.UseVisualStyleBackColor = false;
            this.Monthly_Restorative_Rest.Click += new System.EventHandler(this.Monthly_Restorative_Rest_Click);
            // 
            // Art_Gathering
            // 
            this.Art_Gathering.BackColor = System.Drawing.Color.Crimson;
            this.Art_Gathering.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Art_Gathering.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Art_Gathering.ForeColor = System.Drawing.Color.White;
            this.Art_Gathering.Location = new System.Drawing.Point(1090, 873);
            this.Art_Gathering.Name = "Art_Gathering";
            this.Art_Gathering.Size = new System.Drawing.Size(159, 34);
            this.Art_Gathering.TabIndex = 39;
            this.Art_Gathering.Text = "BOOK NOW";
            this.Art_Gathering.UseVisualStyleBackColor = false;
            this.Art_Gathering.Click += new System.EventHandler(this.Art_Gathering_Click);
            // 
            // Mindfull_Kickboxing
            // 
            this.Mindfull_Kickboxing.BackColor = System.Drawing.Color.Crimson;
            this.Mindfull_Kickboxing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Mindfull_Kickboxing.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mindfull_Kickboxing.ForeColor = System.Drawing.Color.White;
            this.Mindfull_Kickboxing.Location = new System.Drawing.Point(62, 1255);
            this.Mindfull_Kickboxing.Name = "Mindfull_Kickboxing";
            this.Mindfull_Kickboxing.Size = new System.Drawing.Size(159, 34);
            this.Mindfull_Kickboxing.TabIndex = 40;
            this.Mindfull_Kickboxing.Text = "BOOK NOW";
            this.Mindfull_Kickboxing.UseVisualStyleBackColor = false;
            this.Mindfull_Kickboxing.Click += new System.EventHandler(this.button10_Click);
            // 
            // Partner_Assisted_Yoga
            // 
            this.Partner_Assisted_Yoga.BackColor = System.Drawing.Color.Crimson;
            this.Partner_Assisted_Yoga.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Partner_Assisted_Yoga.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Partner_Assisted_Yoga.ForeColor = System.Drawing.Color.White;
            this.Partner_Assisted_Yoga.Location = new System.Drawing.Point(597, 1255);
            this.Partner_Assisted_Yoga.Name = "Partner_Assisted_Yoga";
            this.Partner_Assisted_Yoga.Size = new System.Drawing.Size(159, 34);
            this.Partner_Assisted_Yoga.TabIndex = 41;
            this.Partner_Assisted_Yoga.Text = "BOOK NOW";
            this.Partner_Assisted_Yoga.UseVisualStyleBackColor = false;
            this.Partner_Assisted_Yoga.Click += new System.EventHandler(this.Partner_Assisted_Yoga_Click);
            // 
            // Focusing_Workshop
            // 
            this.Focusing_Workshop.BackColor = System.Drawing.Color.Crimson;
            this.Focusing_Workshop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Focusing_Workshop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Focusing_Workshop.ForeColor = System.Drawing.Color.White;
            this.Focusing_Workshop.Location = new System.Drawing.Point(1077, 1255);
            this.Focusing_Workshop.Name = "Focusing_Workshop";
            this.Focusing_Workshop.Size = new System.Drawing.Size(159, 34);
            this.Focusing_Workshop.TabIndex = 42;
            this.Focusing_Workshop.Text = "BOOK NOW";
            this.Focusing_Workshop.UseVisualStyleBackColor = false;
            this.Focusing_Workshop.Click += new System.EventHandler(this.Focusing_Workshop_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(553, 413);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(10, 16);
            this.label17.TabIndex = 43;
            this.label17.Text = ".";
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Orange;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(992, 444);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(80, 32);
            this.button14.TabIndex = 44;
            this.button14.Text = "Details";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // roundedPanel8
            // 
            this.roundedPanel8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("roundedPanel8.BackgroundImage")));
            this.roundedPanel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundedPanel8.BorderRadius = 50;
            this.roundedPanel8.Location = new System.Drawing.Point(1016, 974);
            this.roundedPanel8.Name = "roundedPanel8";
            this.roundedPanel8.Size = new System.Drawing.Size(287, 199);
            this.roundedPanel8.TabIndex = 27;
            this.roundedPanel8.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel8_Paint);
            // 
            // roundedPanel7
            // 
            this.roundedPanel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("roundedPanel7.BackgroundImage")));
            this.roundedPanel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundedPanel7.BorderRadius = 50;
            this.roundedPanel7.Location = new System.Drawing.Point(532, 974);
            this.roundedPanel7.Name = "roundedPanel7";
            this.roundedPanel7.Size = new System.Drawing.Size(287, 199);
            this.roundedPanel7.TabIndex = 26;
            // 
            // roundedPanel6
            // 
            this.roundedPanel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("roundedPanel6.BackgroundImage")));
            this.roundedPanel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundedPanel6.BorderRadius = 50;
            this.roundedPanel6.Location = new System.Drawing.Point(14, 974);
            this.roundedPanel6.Name = "roundedPanel6";
            this.roundedPanel6.Size = new System.Drawing.Size(287, 199);
            this.roundedPanel6.TabIndex = 25;
            // 
            // roundedPanel3
            // 
            this.roundedPanel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("roundedPanel3.BackgroundImage")));
            this.roundedPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundedPanel3.BorderRadius = 50;
            this.roundedPanel3.Location = new System.Drawing.Point(9, 616);
            this.roundedPanel3.Name = "roundedPanel3";
            this.roundedPanel3.Size = new System.Drawing.Size(287, 199);
            this.roundedPanel3.TabIndex = 20;
            // 
            // roundedPanel5
            // 
            this.roundedPanel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("roundedPanel5.BackgroundImage")));
            this.roundedPanel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundedPanel5.BorderRadius = 50;
            this.roundedPanel5.Location = new System.Drawing.Point(1015, 616);
            this.roundedPanel5.Name = "roundedPanel5";
            this.roundedPanel5.Size = new System.Drawing.Size(287, 199);
            this.roundedPanel5.TabIndex = 16;
            // 
            // roundedPanel4
            // 
            this.roundedPanel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("roundedPanel4.BackgroundImage")));
            this.roundedPanel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundedPanel4.BorderRadius = 50;
            this.roundedPanel4.Location = new System.Drawing.Point(531, 616);
            this.roundedPanel4.Name = "roundedPanel4";
            this.roundedPanel4.Size = new System.Drawing.Size(287, 199);
            this.roundedPanel4.TabIndex = 15;
            this.roundedPanel4.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel4_Paint);
            // 
            // EventForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1369, 679);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.Focusing_Workshop);
            this.Controls.Add(this.Partner_Assisted_Yoga);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.Mindfull_Kickboxing);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Art_Gathering);
            this.Controls.Add(this.Monthly_Restorative_Rest);
            this.Controls.Add(this.Turn_Up_and_Write);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.roundedPanel8);
            this.Controls.Add(this.roundedPanel7);
            this.Controls.Add(this.roundedPanel6);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.roundedPanel3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.roundedPanel5);
            this.Controls.Add(this.roundedPanel4);
            this.Controls.Add(this.panel2);
            this.Name = "EventForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.roundedPanel1.ResumeLayout(false);
            this.roundedPanel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private RoundedPanel roundedPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button5;
        private RoundedPanel roundedPanel4;
        private RoundedPanel roundedPanel5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private RoundedPanel roundedPanel3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox1;
        private RoundedPanel roundedPanel6;
        private RoundedPanel roundedPanel7;
        private RoundedPanel roundedPanel8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Turn_Up_and_Write;
        private System.Windows.Forms.Button Monthly_Restorative_Rest;
        private System.Windows.Forms.Button Art_Gathering;
        private System.Windows.Forms.Button Mindfull_Kickboxing;
        private System.Windows.Forms.Button Partner_Assisted_Yoga;
        private System.Windows.Forms.Button Focusing_Workshop;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
    }
}

